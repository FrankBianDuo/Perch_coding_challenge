import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';


var labInfo = {
  "id": 99,
  "title": "Perch Research Web Development",
  "description": "Help develop the Perch Research web app, which will be used to organize university lab projects from UROP and (in the future) across many universities. Will involve programming in React (Javascript), and PHP",
  "duties": "Attend weekly web development meetings and work sessions. Work with other web development members on different coding assignments on the frontend and backend of thes site",
  "time_commitment": 8,
  "classification": "Software Development"
}

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Lab Info</h1>
        </header>
        <div>   <br></br>    
                <p align="left"> <b>id</b> : {labInfo.id}</p>
                <p align="left"> <b>title</b> : {labInfo.title}</p>
                <p align="left"> <b>description</b> : {labInfo.description}</p>
                <p align="left"> <b>duties</b> : {labInfo.duties}</p>
                <p align="left"> <b>time commitment</b> : {labInfo.time_commitment}</p>
                <p align="left"> <b>classification</b> : {labInfo.classification}</p>
        </div>
      </div>
    );
  }
}

export default App;
